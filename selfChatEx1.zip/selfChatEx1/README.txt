daniel.hazan
203385828

I pledge the highest level of ethical principles in support of academic excellence. 
 I ensure that all of my work reflects my own abilities and not those of someone else